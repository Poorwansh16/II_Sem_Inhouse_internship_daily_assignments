-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2026 at 03:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `faculty_name` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `department` varchar(50) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `faculty_name`, `course_name`, `department`, `semester`, `created_at`) VALUES
(1, 'Mr. Sharma', 'Web Development', 'IT', 'VI', '2026-07-14 10:50:50'),
(2, 'Mrs. Gupta', 'Database Management System', 'IT', 'VI', '2026-07-14 10:50:50'),
(3, 'Mr. Verma', 'Operating System', 'IT', 'VI', '2026-07-14 10:50:50'),
(4, 'Mrs. Singh', 'Data Structures', 'IT', 'VI', '2026-07-14 10:50:50'),
(5, 'Mr. Mehta', 'Object Oriented Programming', 'IT', 'VI', '2026-07-14 10:50:50');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `roll_number` varchar(20) NOT NULL,
  `faculty_name` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `rating` int(11) NOT NULL,
  `comments` text DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `roll_number`, `faculty_name`, `course_name`, `rating`, `comments`, `submitted_at`) VALUES
(1, '25ESK5757', 'Mr. Sharma', 'Web Development', 4, 'you need to improve with interactions', '2026-07-17 11:16:02'),
(2, '25ESK5757', 'Mrs. Gupta', 'Database Management System', 4, '', '2026-07-17 11:21:31'),
(3, '25ESK5757', 'Mr. Verma', 'Operating System', 4, 'we are great', '2026-07-17 14:18:05'),
(4, '25ESKCS257', 'Mrs. Singh', 'Data Structures', 5, '', '2026-07-17 16:08:00'),
(5, '25ESKCS257', 'Mr. Mehta', 'Object Oriented Programming', 5, '', '2026-07-17 16:08:49'),
(6, '25ESKCS123', 'Mr. Sharma', 'Web Development', 3, 'need to improve', '2026-07-21 14:46:52'),
(7, '25ESKCS654', 'Mr. Sharma', 'Web Development', 4, 'just give more practise questions', '2026-07-22 13:03:32'),
(8, '25ESKCS654', 'Mrs. Gupta', 'Database Management System', 4, 'no', '2026-07-22 13:12:08'),
(9, '25ESK5757', 'Mr. Mehta', 'Object Oriented Programming', 4, 'no', '2026-07-23 17:31:58'),
(10, '25ESKCS654', 'Mr. Mehta', 'Object Oriented Programming', 4, 'no', '2026-07-24 11:28:39'),
(11, '25ESKCS654', 'Mrs. Singh', 'Data Structures', 5, '', '2026-07-24 12:13:40'),
(12, '25ESKCX3030', 'Mr. Sharma', 'Web Development', 5, 'NO', '2026-07-24 12:21:23'),
(13, '25ESKCS654', 'Mr. Verma', 'Operating System', 3, '', '2026-07-24 13:14:45');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `roll_number` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `department` varchar(50) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `roll_number`, `password`, `department`, `semester`, `created_at`, `updated_at`) VALUES
(1, 'rohan', '25ESK5757', '123456', 'IT', 'VI', '2026-07-12 06:06:44', '2026-07-12 06:06:44'),
(10, '', '', '', '', '', '2026-07-12 10:13:50', '2026-07-12 10:13:50'),
(13, 'poorwansh choudhary', '25ESKCS257', 'Pc@16032006', 'CSE(DS)', 'III', '2026-07-17 16:06:18', '2026-07-17 16:06:18'),
(14, 'vijay', '25ESKCS123', '654321', 'CSE(DS)', 'III', '2026-07-18 19:07:44', '2026-07-18 19:07:44'),
(15, 'rahul', '25ESKCS321', '1234567', 'CSE', 'III', '2026-07-21 14:52:12', '2026-07-21 14:53:21'),
(16, 'dev', '25ESKCS654', '1333', 'CSE', 'III', '2026-07-22 12:51:14', '2026-07-23 12:36:16'),
(17, 'priya', '25ESKCX3030', '300516', 'CSE(DS)', 'III', '2026-07-24 12:20:04', '2026-07-24 12:20:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roll_number` (`roll_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
